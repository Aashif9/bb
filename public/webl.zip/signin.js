document.addEventListener('DOMContentLoaded', function() {
    // You can add your form submission logic here
    const loginForm = document.querySelector('.login-form');
    loginForm.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent default form submission for now
  
      // Capture email and password values
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
  
      // Here, you would usually handle login via an API or form submission logic.
      // For now, let's just log them to the console:
      console.log('Email:', email);
      console.log('Password:', password);
    });
  });