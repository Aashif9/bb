document.addEventListener("DOMContentLoaded", () => {
    const yearSelect = document.getElementById("graduation-year");
    const currentYear = new Date().getFullYear();
    for (let i = 0; i <= 30; i++) {
      const year = currentYear - i;
      const option = document.createElement("option");
      option.value = year;
      option.textContent = year;
      yearSelect.appendChild(option);
    }
  
    const form = document.getElementById("mentorForm");
    const submitBtn = document.getElementById("submitBtn");
    const statusMsg = document.getElementById("statusMsg");
  
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      submitBtn.disabled = true;
      submitBtn.textContent = "Creating account...";
      statusMsg.textContent = "";
  
      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = "Create Mentor Account";
        statusMsg.textContent = "Mentor account created successfully!";
      }, 1500);
    });
  });