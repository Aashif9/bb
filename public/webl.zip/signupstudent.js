document.getElementById("student-signup-form").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const submitButton = document.getElementById("submit-btn");
    const loadingText = document.getElementById("loading-text");
    
    // Simulate API call
    submitButton.disabled = true;
    loadingText.style.display = "block";
    loadingText.textContent = "Creating account...";
  
    setTimeout(() => {
      submitButton.disabled = false;
      loadingText.style.display = "none";
      alert("Student form submitted");
      console.log("Student form submitted");
    }, 1500); // Simulate 1.5s API delay
  });